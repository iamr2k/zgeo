class GetPointInput:
    def __init__(self, GeoPoint: 'GeoPoint', RangeKeyValue: str):
        self.GeoPoint = GeoPoint
        self.RangeKeyValue = RangeKeyValue
